package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestWebPage {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://techpub-connect-demo.netlify.app/html/contactus.html");
		driver.manage().window().maximize();
		
		
		WebElement element = driver.findElement(By.xpath("/html/body/main/section[1]/div[2]/div/div/div/h1"));
		
		
		
		WebElement el = driver.findElement(By.xpath("/html/body/main/div/section[2]/div/div/div[3]/div/form/div[1]/input"));
		el.sendKeys("Snehal");
		
		WebElement e2 = driver.findElement(By.xpath("/html/body/main/div/section[2]/div/div/div[3]/div/form/div[2]/input"));
		e2.sendKeys("1234567890");
		
		WebElement e3 = driver.findElement(By.xpath("/html/body/main/div/section[2]/div/div/div[3]/div/form/div[3]/input"));
		e3.sendKeys("snehal@19");
		
		WebElement e4 = driver.findElement(By.xpath("/html/body/main/div/section[2]/div/div/div[3]/div/form/div[4]/input"));
		e4.sendKeys("Selenium");
		
		WebElement e5 = driver.findElement(By.xpath("//*[@id=\"commnent\"]"));
		e5.sendKeys("I am a fresher");
		
		WebElement e6 = driver.findElement(By.xpath("/html/body/main/div/section[2]/div/div/div[3]/div/div/button"));
		e6.click();
		
		WebElement e7 = driver.findElement(By.xpath("/html/body/main/section[2]/div/div/div/div[2]/div/div/form/input"));
		e7.sendKeys("snehal@gmail.com");
		
		WebElement e8 = driver.findElement(By.xpath("/html/body/main/section[2]/div/div/div/div[2]/div/div/button"));
		e8.click();
	}

}
